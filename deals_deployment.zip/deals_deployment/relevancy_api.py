from ernie import SentenceClassifier, Models
from flask import Flask, request, render_template, jsonify
import datetime
import sys
import os
import socket
import argparse
import numpy as np
import pandas as pd

app = Flask(__name__)
app.config["DEBUG"] = True

@app.route('/', methods=['GET'])
@app.route('/home', methods=['GET'])
def home():
    return render_template('home.html',
                           title='Home',
                           host=host,
                           port=port)

@app.route('/query',methods=['GET'])
def query():

    try:

        deal_id = int(request.args['deal_id'])

    except Exception as e:

        return jsonify({'text':None,'error':repr(e),'pred':None})

    try:

        text = request.args['text']

    except Exception as e:

        return jsonify({'text':None,'error':repr(e),'pred':None})

    # prob_list = model.predict_one(text)

    # pred=np.argmax(prob_list)

    result = {'text':text,'error':None,'pred':str(np.argmax(model.predict_one(text)))}

    return jsonify(result)

if __name__ == '__main__':

    hostname = socket.gethostname()
    host = socket.gethostbyname(hostname)
    print(host)

    print('Python %s on %s' % (sys.version, sys.platform))

    model = SentenceClassifier(model_path=r'#Deals_Deployment_model Folder')


    parser = argparse.ArgumentParser()
    parser.add_argument("--port",
                        default=6578,
                        type=int,
                        help="Port to be used for the Flask Application.")
    args = parser.parse_args()
    port = int(args.port)

    app.run(host=host, port=port, debug=True, threaded=True)

